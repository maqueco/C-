//weather_utils.c: Implementación de las funciones mencionadas a continuación.
#ifndef _WEATHER_UTILS_H //si no esta definido la funcion de main
#define _WEATHER_UTILS_H // que lo defina 
#define EXPECTED_WEATHER_UTILS_FILE_FORMAT "%d"
//#include "weather_utils.c"


//void array_years(WeatherTable array, int output[]);

int tempMin (WeatherTable array);

#endif


