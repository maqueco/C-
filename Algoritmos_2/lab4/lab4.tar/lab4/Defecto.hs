module Defecto where

class Defecto d where
  defecto :: d


